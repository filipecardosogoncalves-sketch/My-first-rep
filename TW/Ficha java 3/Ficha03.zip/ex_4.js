/*Ordem alfabetica*/
let Lista=[]
let nome1=prompt("Digite um nome:");
Lista.push(nome1);
let nome2=prompt("Digite um nome:");
Lista.push(nome2);
let nome3=prompt("Digite um nome:");
Lista.push(nome3);

let List=Lista.sort()

alert(`${List[0]}, ${List[1]} e ${List[2]}`)



