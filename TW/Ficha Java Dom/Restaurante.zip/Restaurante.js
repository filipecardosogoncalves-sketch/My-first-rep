let Lista = []
let Menu = document.querySelectorAll("li")
for(let i = 0; i<Menu.length;i++){
    console.log(Menu[i].innerHTML)
    Lista.push(Menu[i].innerHTML)
}


let botao = document.querySelector("button");
botao.addEventListener("click", function() {
    let novoPrato = prompt("Digite o nome do novo prato:");
    if(novoPrato){
        let novaLinha= document.createElement("li");
        let texto = document.createTextNode(novoPrato);
        novaLinha.appendChild(texto);
        document.querySelector("ul").appendChild(novaLinha);
    }
});

let titulo = document.querySelector("h1");

titulo.addEventListener("mouseover", function() {
    titulo.style.color = "blue";
});
titulo.addEventListener("mouseout", function() {
    titulo.style.color = "";
});