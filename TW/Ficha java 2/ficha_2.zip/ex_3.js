/*Exercicio 4*/

function par() {
    for (i=1; i<=10;i++){
        if (i%2==0) {
            console.log(`${i} é um número par`);
        } else {
            console.log(`${i} é impar`);
            
        }
    }
}
par()