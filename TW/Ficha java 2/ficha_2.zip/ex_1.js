/*Exercicio Tabuada*/

let num = prompt("Digite um número:")

for (let i=1; i<11;i++){
    let tabuada = i * num
    console.log(`${i} x ${num} = ${tabuada}`);
}