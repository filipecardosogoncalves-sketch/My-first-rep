let num = prompt("Digite um número")

if(num%2==0){
    alert("O número é par")
} else{
    alert("O número é impar")
}