let num1 = prompt("Digite um número: ")
let num2 = prompt("Digite outro número: ")

if(num1==num2){
    alert("Não pode digitar dois numeros iguais")
} else if(num1>num2){
    alert("O primeiro número é o maior")
} else{
    alert("O segundo número é o maior")
}
